library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity CTL_ROT is
  generic (
    PWM_MAX      : integer := 3125;
    ROT_SPEED    : integer := 2200;
    CENTER_TOL   : integer := 1;
    STABLE_COUNT : integer := 2
  );
  port (
    clk          : in  std_logic;
    reset_n      : in  std_logic;
    start_rot    : in  std_logic;
    dir_rot      : in  std_logic;  -- 0 = droite, 1 = gauche
    ligne_pres   : in  std_logic;
    pos_ligne    : in  signed(3 downto 0);
    fin_rot      : out std_logic;
    moteur_r_cmd : out std_logic_vector(13 downto 0);
    moteur_l_cmd : out std_logic_vector(13 downto 0)
  );
end entity;

architecture rtl of CTL_ROT is
  type state_t is (IDLE, RUN, DONE);
  subtype cmd_t is std_logic_vector(13 downto 0);

  signal state_s       : state_t := IDLE;
  signal fin_rot_s     : std_logic := '0';
  signal moteur_r_s    : cmd_t := (others => '0');
  signal moteur_l_s    : cmd_t := (others => '0');
  signal centered_cnt  : integer range 0 to STABLE_COUNT := 0;

  function clamp_pwm(v : integer) return integer is
  begin
    if v < 0 then
      return 0;
    elsif v > PWM_MAX then
      return PWM_MAX;
    else
      return v;
    end if;
  end function;

  function make_cmd(go_b : std_logic; dir_b : std_logic; speed_i : integer) return cmd_t is
    variable tmp : cmd_t := (others => '0');
    variable sat : integer;
  begin
    sat := clamp_pwm(speed_i);
    tmp(13) := go_b;
    tmp(12) := dir_b;
    tmp(11 downto 0) := std_logic_vector(to_unsigned(sat, 12));
    return tmp;
  end function;

begin
  fin_rot      <= fin_rot_s;
  moteur_r_cmd <= moteur_r_s;
  moteur_l_cmd <= moteur_l_s;

  process(clk, reset_n)
    variable pos_i : integer;
  begin
    if reset_n = '0' then
      state_s      <= IDLE;
      fin_rot_s    <= '0';
      moteur_r_s   <= (others => '0');
      moteur_l_s   <= (others => '0');
      centered_cnt <= 0;

    elsif rising_edge(clk) then
      case state_s is

        when IDLE =>
          fin_rot_s    <= '0';
          moteur_r_s   <= (others => '0');
          moteur_l_s   <= (others => '0');
          centered_cnt <= 0;

          if start_rot = '1' then
            state_s <= RUN;
          end if;

        when RUN =>
          if start_rot = '0' then
            state_s      <= IDLE;
            fin_rot_s    <= '0';
            moteur_r_s   <= (others => '0');
            moteur_l_s   <= (others => '0');
            centered_cnt <= 0;

          else
            pos_i := to_integer(pos_ligne);

            if (ligne_pres = '1') and (pos_i >= -CENTER_TOL) and (pos_i <= CENTER_TOL) then
              if centered_cnt < STABLE_COUNT then
                centered_cnt <= centered_cnt + 1;
              end if;

              if centered_cnt = STABLE_COUNT - 1 then
                state_s      <= DONE;
                fin_rot_s    <= '1';
                moteur_r_s   <= (others => '0');
                moteur_l_s   <= (others => '0');
                centered_cnt <= 0;
              else
                fin_rot_s <= '0';
                if dir_rot = '0' then
                  moteur_r_s <= make_cmd('1', '1', ROT_SPEED);
                  moteur_l_s <= make_cmd('1', '0', ROT_SPEED);
                else
                  moteur_r_s <= make_cmd('1', '0', ROT_SPEED);
                  moteur_l_s <= make_cmd('1', '1', ROT_SPEED);
                end if;
              end if;

            else
              centered_cnt <= 0;
              fin_rot_s    <= '0';

              if dir_rot = '0' then
                -- rotation à droite
                moteur_r_s <= make_cmd('1', '1', ROT_SPEED);
                moteur_l_s <= make_cmd('1', '0', ROT_SPEED);
              else
                -- rotation à gauche
                moteur_r_s <= make_cmd('1', '0', ROT_SPEED);
                moteur_l_s <= make_cmd('1', '1', ROT_SPEED);
              end if;
            end if;
          end if;

        when DONE =>
          fin_rot_s    <= '1';
          moteur_r_s   <= (others => '0');
          moteur_l_s   <= (others => '0');
          centered_cnt <= 0;

          if start_rot = '0' then
            state_s <= IDLE;
          end if;

      end case;
    end if;
  end process;

end architecture;