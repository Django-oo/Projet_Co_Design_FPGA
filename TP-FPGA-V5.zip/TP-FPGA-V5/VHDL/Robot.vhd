LIBRARY ieee;
USE ieee.std_logic_1164.ALL;

ENTITY Robot IS
PORT (
    CLOCK_50 : IN  STD_LOGIC;
    KEY      : IN  STD_LOGIC_VECTOR(1 DOWNTO 0);
    SW       : IN  STD_LOGIC_VECTOR(7 DOWNTO 0);
    LED      : OUT STD_LOGIC_VECTOR(7 DOWNTO 0);

    -- SDRAM (Terasic DE0-NANO)
    DRAM_ADDR  : OUT   STD_LOGIC_VECTOR(12 DOWNTO 0);
    DRAM_BA    : OUT   STD_LOGIC_VECTOR(1 DOWNTO 0);
    DRAM_CAS_N : OUT   STD_LOGIC;
    DRAM_CKE   : OUT   STD_LOGIC;
    DRAM_CLK   : OUT   STD_LOGIC;
    DRAM_CS_N  : OUT   STD_LOGIC;
    DRAM_DQ    : INOUT STD_LOGIC_VECTOR(15 DOWNTO 0);
    DRAM_DQM   : OUT   STD_LOGIC_VECTOR(1 DOWNTO 0);
    DRAM_RAS_N : OUT   STD_LOGIC;
    DRAM_WE_N  : OUT   STD_LOGIC;

    -- Motor driver (Smart Car Daughtercard)
    MTRR_N       : OUT STD_LOGIC;
    MTRR_P       : OUT STD_LOGIC;
    MTRL_P       : OUT STD_LOGIC;
    MTRL_N       : OUT STD_LOGIC;
    MTR_Sleep_n  : OUT STD_LOGIC;
    MTR_Fault_n  : IN  STD_LOGIC;

    -- Power enable (active low)
    VCC3P3_PWRON_n : OUT STD_LOGIC
);
END Robot;

ARCHITECTURE rtl OF Robot IS

    -- Qsys system
    COMPONENT system IS
        PORT (
            leds_export        : OUT   STD_LOGIC_VECTOR(7 DOWNTO 0);
            switches_export    : IN    STD_LOGIC_VECTOR(7 DOWNTO 0);
            clk_clk            : IN    STD_LOGIC;
            reset_reset_n      : IN    STD_LOGIC;

            sdram_wire_addr    : OUT   STD_LOGIC_VECTOR(12 DOWNTO 0);
            sdram_wire_ba      : OUT   STD_LOGIC_VECTOR(1 DOWNTO 0);
            sdram_wire_cas_n   : OUT   STD_LOGIC;
            sdram_wire_cke     : OUT   STD_LOGIC;
            sdram_wire_cs_n    : OUT   STD_LOGIC;
            sdram_wire_dq      : INOUT STD_LOGIC_VECTOR(15 DOWNTO 0);
            sdram_wire_dqm     : OUT   STD_LOGIC_VECTOR(1 DOWNTO 0);
            sdram_wire_ras_n   : OUT   STD_LOGIC;
            sdram_wire_we_n    : OUT   STD_LOGIC;

            sdram_clk_clk      : OUT   STD_LOGIC;

            motor_right_export : OUT   STD_LOGIC_VECTOR(13 DOWNTO 0);
            motor_left_export  : OUT   STD_LOGIC_VECTOR(13 DOWNTO 0)
        );
    END COMPONENT;

    -- PWM generation (ton fichier PWM_generation.vhd)
    COMPONENT PWM_generation IS
        PORT(
            clk, reset_n : IN  STD_LOGIC;
            s_writedataR : IN  STD_LOGIC_VECTOR(13 DOWNTO 0);
            s_writedataL : IN  STD_LOGIC_VECTOR(13 DOWNTO 0);
            dc_motor_p_R : OUT STD_LOGIC;
            dc_motor_n_R : OUT STD_LOGIC;
            dc_motor_p_L : OUT STD_LOGIC;
            dc_motor_n_L : OUT STD_LOGIC
        );
    END COMPONENT;

    SIGNAL rst_n      : STD_LOGIC;
    SIGNAL leds_sys   : STD_LOGIC_VECTOR(7 DOWNTO 0);
    SIGNAL motor_r    : STD_LOGIC_VECTOR(13 DOWNTO 0);
    SIGNAL motor_l    : STD_LOGIC_VECTOR(13 DOWNTO 0);

BEGIN

    -- KEY0 active low reset (Quartus/Terasic convention)
    rst_n <= KEY(0);

    -- Power enable for daughtercard + wake motor driver
    VCC3P3_PWRON_n <= '0';
    MTR_Sleep_n    <= '1';

    -- Qsys system instance
    u_sys : system
    PORT MAP (
        clk_clk            => CLOCK_50,
        reset_reset_n      => rst_n,

        switches_export    => SW,
        leds_export        => leds_sys,

        sdram_wire_addr    => DRAM_ADDR,
        sdram_wire_ba      => DRAM_BA,
        sdram_wire_cas_n   => DRAM_CAS_N,
        sdram_wire_cke     => DRAM_CKE,
        sdram_wire_cs_n    => DRAM_CS_N,
        sdram_wire_dq      => DRAM_DQ,
        sdram_wire_dqm     => DRAM_DQM,
        sdram_wire_ras_n   => DRAM_RAS_N,
        sdram_wire_we_n    => DRAM_WE_N,

        sdram_clk_clk      => DRAM_CLK,

        motor_right_export => motor_r,
        motor_left_export  => motor_l
    );

    -- PWM + direction to motor driver pins
    u_pwm : PWM_generation
    PORT MAP (
        clk          => CLOCK_50,
        reset_n      => rst_n,
        s_writedataR => motor_r,
        s_writedataL => motor_l,
        dc_motor_p_R => MTRR_P,
        dc_motor_n_R => MTRR_N,
        dc_motor_p_L => MTRL_P,
        dc_motor_n_L => MTRL_N
    );

    -- LEDs from Nios (debug via software)
    LED <= leds_sys;

END rtl;
