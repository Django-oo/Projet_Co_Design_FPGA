#include <stdint.h>

/*
 * Superviseur Nios II - Aller/retour avec suivi de ligne
 *
 * Architecture visee :
 *   - Le Nios pilote les automates VHDL via un registre de sortie PORT_S.
 *   - Le Nios lit les retours des automates via un registre d'entree PORT_E.
 *   - Les blocs VHDL CTL_SL / CTL_ROT pilotent eux-memes les moteurs.
 *
 * Registre PORT_S (ecriture, 16 bits)
 *   bit 0 : start_sl
 *   bit 1 : start_rot
 *   bit 2 : dir_rot   (0 = droite, 1 = gauche)
 *
 * Registre PORT_E (lecture, 16 bits)
 *   bit 0 : fin_sl
 *   bit 1 : fin_rot
 *   bits 5:2 : pos_ligne signee sur 4 bits (-6 .. +6)
 *   bit 6 : ligne_pres
 *
 * Adapte uniquement PORT_S_BASE et PORT_E_BASE a ton systeme Qsys.
 */

#define REG16(addr) (*(volatile uint16_t *)(addr))

/* -------------------------------------------------------------------------- */
/* ADRESSES A ADAPTER SELON TON QSYS                                          */
/* -------------------------------------------------------------------------- */
#define PORT_S_BASE 0x000000A0u
#define PORT_E_BASE 0x000000B0u

/* -------------------------------------------------------------------------- */
/* MAPPING DES BITS                                                           */
/* -------------------------------------------------------------------------- */
#define PORT_S_START_SL_MASK   (1u << 0)
#define PORT_S_START_ROT_MASK  (1u << 1)
#define PORT_S_DIR_ROT_MASK    (1u << 2)

#define PORT_E_FIN_SL_MASK     (1u << 0)
#define PORT_E_FIN_ROT_MASK    (1u << 1)
#define PORT_E_POS_SHIFT       2u
#define PORT_E_POS_MASK        (0xFu << PORT_E_POS_SHIFT)
#define PORT_E_LINE_MASK       (1u << 6)

#define DIR_ROT_DROITE         0u
#define DIR_ROT_GAUCHE         1u

#define TEMPO_STOP_MS          1000u
#define POLL_DELAY_MS          5u
#define LOOPS_PER_MS           5000u

/* -------------------------------------------------------------------------- */
/* DELAY LOGICIEL                                                             */
/* -------------------------------------------------------------------------- */
static void delay_ms(uint32_t ms)
{
    volatile uint32_t i;
    volatile uint32_t j;

    for (j = 0u; j < ms; ++j) {
        for (i = 0u; i < LOOPS_PER_MS; ++i) {
        }
    }
}

/* -------------------------------------------------------------------------- */
/* ACCES REGISTRES                                                            */
/* -------------------------------------------------------------------------- */
static void write_port_s(uint8_t start_sl, uint8_t start_rot, uint8_t dir_rot)
{
    uint16_t v = 0u;

    if (start_sl != 0u) {
        v |= (uint16_t)PORT_S_START_SL_MASK;
    }
    if (start_rot != 0u) {
        v |= (uint16_t)PORT_S_START_ROT_MASK;
    }
    if (dir_rot != 0u) {
        v |= (uint16_t)PORT_S_DIR_ROT_MASK;
    }

    REG16(PORT_S_BASE) = v;
}

static uint16_t read_port_e(void)
{
    return REG16(PORT_E_BASE);
}

static uint8_t read_fin_sl(void)
{
    return ((read_port_e() & PORT_E_FIN_SL_MASK) != 0u) ? 1u : 0u;
}

static uint8_t read_fin_rot(void)
{
    return ((read_port_e() & PORT_E_FIN_ROT_MASK) != 0u) ? 1u : 0u;
}

static uint8_t read_ligne_pres(void)
{
    return ((read_port_e() & PORT_E_LINE_MASK) != 0u) ? 1u : 0u;
}

static int8_t read_pos_ligne(void)
{
    uint8_t raw4;

    raw4 = (uint8_t)((read_port_e() & PORT_E_POS_MASK) >> PORT_E_POS_SHIFT);

    /* extension de signe 4 bits -> int8_t */
    if ((raw4 & 0x8u) != 0u) {
        raw4 |= 0xF0u;
    }

    return (int8_t)raw4;
}

/* -------------------------------------------------------------------------- */
/* CHOIX DU SENS DE ROTATION                                                  */
/* -------------------------------------------------------------------------- */
static uint8_t choose_rotation_dir(int8_t last_pos, uint8_t previous_dir)
{
    /*
     * Strategie :
     *   - si la ligne a ete perdue franchement d'un cote, on tourne de ce cote
     *   - sinon on alterne pour garantir les aller-retours
     *
     * Attention : selon le sens physique de numerotation de tes capteurs,
     * il faudra peut-etre inverser DROITE et GAUCHE ci-dessous.
     */
    if (last_pos >= 2) {
        return DIR_ROT_DROITE;
    }
    if (last_pos <= -2) {
        return DIR_ROT_GAUCHE;
    }

    return (previous_dir == DIR_ROT_GAUCHE) ? DIR_ROT_DROITE : DIR_ROT_GAUCHE;
}

/* -------------------------------------------------------------------------- */
/* MACHINE A ETATS                                                            */
/* -------------------------------------------------------------------------- */
typedef enum {
    ETAT_INIT = 0,
    ETAT_ATTENTE_LIGNE,
    ETAT_LANCE_SL,
    ETAT_SUIVI_LIGNE,
    ETAT_STOP_1S_AVANT_ROT,
    ETAT_LANCE_ROT,
    ETAT_ROTATION,
    ETAT_STOP_1S_AVANT_SL
} robot_state_t;

int main(void)
{
    robot_state_t state = ETAT_INIT;
    uint8_t dir_rot = DIR_ROT_GAUCHE;
    int8_t last_pos = 0;

    while (1) {
        switch (state) {

        case ETAT_INIT:
            write_port_s(0u, 0u, dir_rot);
            state = ETAT_ATTENTE_LIGNE;
            break;

        case ETAT_ATTENTE_LIGNE:
            write_port_s(0u, 0u, dir_rot);

            if (read_ligne_pres() != 0u) {
                state = ETAT_LANCE_SL;
            } else {
                delay_ms(POLL_DELAY_MS);
            }
            break;

        case ETAT_LANCE_SL:
            write_port_s(1u, 0u, dir_rot);
            state = ETAT_SUIVI_LIGNE;
            break;

        case ETAT_SUIVI_LIGNE:
            write_port_s(1u, 0u, dir_rot);

            if (read_ligne_pres() != 0u) {
                last_pos = read_pos_ligne();
            }

            if (read_fin_sl() != 0u) {
                write_port_s(0u, 0u, dir_rot);
                state = ETAT_STOP_1S_AVANT_ROT;
            } else {
                delay_ms(POLL_DELAY_MS);
            }
            break;

        case ETAT_STOP_1S_AVANT_ROT:
            write_port_s(0u, 0u, dir_rot);
            delay_ms(TEMPO_STOP_MS);
            dir_rot = choose_rotation_dir(last_pos, dir_rot);
            state = ETAT_LANCE_ROT;
            break;

        case ETAT_LANCE_ROT:
            write_port_s(0u, 1u, dir_rot);
            state = ETAT_ROTATION;
            break;

        case ETAT_ROTATION:
            write_port_s(0u, 1u, dir_rot);

            if (read_fin_rot() != 0u) {
                write_port_s(0u, 0u, dir_rot);
                state = ETAT_STOP_1S_AVANT_SL;
            } else {
                delay_ms(POLL_DELAY_MS);
            }
            break;

        case ETAT_STOP_1S_AVANT_SL:
            write_port_s(0u, 0u, dir_rot);
            delay_ms(TEMPO_STOP_MS);
            state = ETAT_LANCE_SL;
            break;

        default:
            write_port_s(0u, 0u, dir_rot);
            state = ETAT_INIT;
            break;
        }
    }
}
