library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity CTL_SL is
  generic (
    PWM_MAX    : integer := 3125;
    BASE_SPEED : integer := 2000;
    MIN_SPEED  : integer := 700;
    TRIM_R     : integer := 0;
    TRIM_L     : integer := 0
  );
  port (
    clk          : in  std_logic;
    reset_n      : in  std_logic;
    start_sl     : in  std_logic;
    ligne_pres   : in  std_logic;
    pos_ligne    : in  signed(3 downto 0);
    fin_sl       : out std_logic;
    moteur_r_cmd : out std_logic_vector(13 downto 0);
    moteur_l_cmd : out std_logic_vector(13 downto 0)
  );
end entity;

architecture rtl of CTL_SL is
  type state_t is (IDLE, RUN, DONE);
  subtype cmd_t is std_logic_vector(13 downto 0);

  signal state_s    : state_t := IDLE;
  signal fin_sl_s   : std_logic := '0';
  signal moteur_r_s : cmd_t := (others => '0');
  signal moteur_l_s : cmd_t := (others => '0');


  constant K_POS : integer := 180;

  function clamp_pwm(v : integer) return integer is
  begin
    if v < 0 then
      return 0;
    elsif v > PWM_MAX then
      return PWM_MAX;
    else
      return v;
    end if;
  end function;

  function make_cmd(go_b : std_logic; dir_b : std_logic; speed_i : integer) return cmd_t is
    variable tmp : cmd_t := (others => '0');
    variable sat : integer;
  begin
    sat := clamp_pwm(speed_i);
    tmp(13) := go_b;
    tmp(12) := dir_b;
    tmp(11 downto 0) := std_logic_vector(to_unsigned(sat, 12));
    return tmp;
  end function;

begin
  fin_sl       <= fin_sl_s;
  moteur_r_cmd <= moteur_r_s;
  moteur_l_cmd <= moteur_l_s;

  process(clk, reset_n)
    variable pos_i  : integer;
    variable corr_i : integer;
    variable vit_r  : integer;
    variable vit_l  : integer;
  begin
    if reset_n = '0' then
      state_s    <= IDLE;
      fin_sl_s   <= '0';
      moteur_r_s <= (others => '0');
      moteur_l_s <= (others => '0');

    elsif rising_edge(clk) then
      case state_s is

        when IDLE =>
          fin_sl_s   <= '0';
          moteur_r_s <= (others => '0');
          moteur_l_s <= (others => '0');

          if start_sl = '1' then
            state_s <= RUN;
          end if;

        when RUN =>
          if start_sl = '0' then
            state_s    <= IDLE;
            fin_sl_s   <= '0';
            moteur_r_s <= (others => '0');
            moteur_l_s <= (others => '0');

          elsif ligne_pres = '0' then
            state_s    <= DONE;
            fin_sl_s   <= '1';
            moteur_r_s <= (others => '0');
            moteur_l_s <= (others => '0');

          else
            pos_i  := to_integer(pos_ligne);
            corr_i := pos_i * K_POS;

            vit_r := BASE_SPEED + TRIM_R + corr_i;
            vit_l := BASE_SPEED + TRIM_L - corr_i;

            vit_r := clamp_pwm(vit_r);
            vit_l := clamp_pwm(vit_l);


            if (vit_r > 0) and (vit_r < MIN_SPEED) then
              vit_r := MIN_SPEED;
            end if;

            if (vit_l > 0) and (vit_l < MIN_SPEED) then
              vit_l := MIN_SPEED;
            end if;

            vit_r := clamp_pwm(vit_r);
            vit_l := clamp_pwm(vit_l);

            fin_sl_s   <= '0';
            moteur_r_s <= make_cmd('1', '0', vit_r);
            moteur_l_s <= make_cmd('1', '0', vit_l);
          end if;

        when DONE =>
          fin_sl_s   <= '1';
          moteur_r_s <= (others => '0');
          moteur_l_s <= (others => '0');

          if start_sl = '0' then
            state_s <= IDLE;
          end if;

      end case;
    end if;
  end process;

end architecture;