#include <stdint.h>

/* Base addresses (Qsys Address Map) */
#define MOTOR_LEFT_BASE   0x00000000u
#define MOTOR_RIGHT_BASE  0x00000010u

/* Motor cmd format (PWM_generation.vhd)
   bit13 = GO
   bit12 = DIR (0 = forward)
   bits11..0 = speed ticks (0..3125 typ.)
*/
#define MOTOR_GO_BIT      (1u << 13)
#define MOTOR_DIR_BIT     (1u << 12)
#define MOTOR_SPEED_MASK  0x0FFFu

/* Choose speed: 0..3125 (ex: 2000 ~ assez fort) */
#define SPEED_TICKS       2000u

static inline void write32(uint32_t addr, uint32_t value)
{
    *(volatile uint32_t *)addr = value;
}

int main(void)
{
    uint32_t cmd = MOTOR_GO_BIT | (SPEED_TICKS & MOTOR_SPEED_MASK); /* forward */

    write32(MOTOR_LEFT_BASE,  cmd);
    write32(MOTOR_RIGHT_BASE, cmd);

    while (1)
    {
        /* nothing */
    }

    return 0;
}
