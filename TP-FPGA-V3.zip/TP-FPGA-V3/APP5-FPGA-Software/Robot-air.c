#include <stdint.h>
#include <stdbool.h>


#define WRITEDATA_L  ((volatile uint32_t *)0x00000000u)
#define WRITEDATA_R  ((volatile uint32_t *)0x00000010u)

static void wait_cycles(volatile uint32_t cycles)
{
    while (cycles--) { __asm__ volatile ("nop"); }
}

int main(void)
{
    bool go_l = true,  dir_l = true;
    bool go_r = true,  dir_r = true;

    uint16_t duty_l = 0;
    uint16_t duty_r = 0;

    while (1)
    {
        uint32_t cmd;

        cmd  = ((uint32_t)(go_l ? 1u : 0u) << 13);
        cmd |= ((uint32_t)(dir_l ? 1u : 0u) << 12);
        cmd |= ((uint32_t)(duty_l & 0x0FFFu));
        *WRITEDATA_L = cmd;

        cmd  = ((uint32_t)(go_r ? 1u : 0u) << 13);
        cmd |= ((uint32_t)(dir_r ? 1u : 0u) << 12);
        cmd |= ((uint32_t)(duty_r & 0x0FFFu));
        *WRITEDATA_R = cmd;

        /* ~1 seconde si Nios tourne à 50 MHz (approx) */
        wait_cycles(50000000u);

        /* Incrémente sans dépasser 3125 */
        if (duty_l + 25u <= 3125u) duty_l = (uint16_t)(duty_l + 25u);
        if (duty_r + 25u <= 3125u) duty_r = (uint16_t)(duty_r + 25u);
    }
}
