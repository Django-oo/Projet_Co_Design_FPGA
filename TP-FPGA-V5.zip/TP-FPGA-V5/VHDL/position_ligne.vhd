library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity position_ligne is
  port (
    CLOCK_50 : in  std_logic;
    KEY      : in  std_logic_vector(1 downto 0);
    SW       : in  std_logic_vector(3 downto 0);
    LED      : out std_logic_vector(7 downto 0);

    DRAM_CLK   : out   std_logic;
    DRAM_CKE   : out   std_logic;
    DRAM_ADDR  : out   std_logic_vector(12 downto 0);
    DRAM_BA    : out   std_logic_vector(1 downto 0);
    DRAM_CS_N  : out   std_logic;
    DRAM_CAS_N : out   std_logic;
    DRAM_RAS_N : out   std_logic;
    DRAM_WE_N  : out   std_logic;
    DRAM_DQ    : inout std_logic_vector(15 downto 0);
    DRAM_DQM   : out   std_logic_vector(1 downto 0);

    MTRR_P : out std_logic;
    MTRR_N : out std_logic;
    MTRL_P : out std_logic;
    MTRL_N : out std_logic;

    MTR_Fault_n : in  std_logic;
    MTR_Sleep_n : out std_logic;

    LTC_ADC_CONVST : out std_logic;
    LTC_ADC_SCK    : out std_logic;
    LTC_ADC_SDI    : out std_logic;
    LTC_ADC_SDO    : in  std_logic;

    VCC3P3_PWRON_n : out std_logic
  );
end entity;

architecture Structure of position_ligne is

  component system is
    port (
      leds_export        : out   std_logic_vector(7 downto 0);
      switches_export    : in    std_logic_vector(7 downto 0)  := (others => 'X');
      clk_clk            : in    std_logic                     := 'X';
      reset_reset_n      : in    std_logic                     := 'X';

      sdram_wire_addr    : out   std_logic_vector(12 downto 0);
      sdram_wire_ba      : out   std_logic_vector(1 downto 0);
      sdram_wire_cas_n   : out   std_logic;
      sdram_wire_cke     : out   std_logic;
      sdram_wire_cs_n    : out   std_logic;
      sdram_wire_dq      : inout std_logic_vector(15 downto 0) := (others => 'X');
      sdram_wire_dqm     : out   std_logic_vector(1 downto 0);
      sdram_wire_ras_n   : out   std_logic;
      sdram_wire_we_n    : out   std_logic;
      sdram_clk_clk      : out   std_logic;

      motor_right_export : out   std_logic_vector(13 downto 0);
      motor_left_export  : out   std_logic_vector(13 downto 0);

      pos_export         : in    std_logic_vector(6 downto 0)  := (others => 'X');

      data0r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data1r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data2r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data3r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data4r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data5r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data6r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X')
    );
  end component;

  component capteurs_sol is
    port (
      clk          : in  std_logic;
      reset_n      : in  std_logic;
      data_capture : in  std_logic;
      data_readyr  : out std_logic;

      data0r       : out std_logic_vector(7 downto 0);
      data1r       : out std_logic_vector(7 downto 0);
      data2r       : out std_logic_vector(7 downto 0);
      data3r       : out std_logic_vector(7 downto 0);
      data4r       : out std_logic_vector(7 downto 0);
      data5r       : out std_logic_vector(7 downto 0);
      data6r       : out std_logic_vector(7 downto 0);

      ADC_CONVSTr  : out std_logic;
      ADC_SCK      : out std_logic;
      ADC_SDIr     : out std_logic;
      ADC_SDO      : in  std_logic
    );
  end component;

  component pll_2freqs is
    port (
      areset : in  std_logic := '0';
      inclk0 : in  std_logic := '0';
      c0     : out std_logic;
      c1     : out std_logic
    );
  end component;

  signal rst_n   : std_logic;
  signal clk40   : std_logic;
  signal clk2k   : std_logic;

  signal sw_ext : std_logic_vector(7 downto 0);

  signal led_nios : std_logic_vector(7 downto 0);

  signal motor_right_dummy : std_logic_vector(13 downto 0);
  signal motor_left_dummy  : std_logic_vector(13 downto 0);

  signal data0r_s : std_logic_vector(7 downto 0);
  signal data1r_s : std_logic_vector(7 downto 0);
  signal data2r_s : std_logic_vector(7 downto 0);
  signal data3r_s : std_logic_vector(7 downto 0);
  signal data4r_s : std_logic_vector(7 downto 0);
  signal data5r_s : std_logic_vector(7 downto 0);
  signal data6r_s : std_logic_vector(7 downto 0);

  signal data_ready_s : std_logic;

  signal vect_capt_s  : std_logic_vector(6 downto 0);
  signal ligne_pres_s : std_logic;
  signal pos_ligne_s  : signed(3 downto 0);
  signal pos_to_nios  : std_logic_vector(6 downto 0);

begin

  rst_n <= KEY(0);

  -- Seuil 8 bits à partir des 4 switches
  -- 0000 -> 0x00, 0001 -> 0x11, ..., 1111 -> 0xFF
  sw_ext <= x"6E"; -- 110

  -- Alimentation robot activée
  VCC3P3_PWRON_n <= '0';

  -- Driver moteur endormi pendant le debug
  MTR_Sleep_n <= '0';

  -- Moteurs à l'arrêt
  MTRR_P <= '0';
  MTRR_N <= '0';
  MTRL_P <= '0';
  MTRL_N <= '0';

  u_pll : pll_2freqs
    port map (
      areset => not rst_n,
      inclk0 => CLOCK_50,
      c0     => clk40,
      c1     => clk2k
    );

  u_caps : capteurs_sol
    port map (
      clk          => clk40,
      reset_n      => rst_n,
      data_capture => clk2k,
      data_readyr  => data_ready_s,

      data0r       => data0r_s,
      data1r       => data1r_s,
      data2r       => data2r_s,
      data3r       => data3r_s,
      data4r       => data4r_s,
      data5r       => data5r_s,
      data6r       => data6r_s,

      ADC_CONVSTr  => LTC_ADC_CONVST,
      ADC_SCK      => LTC_ADC_SCK,
      ADC_SDIr     => LTC_ADC_SDI,
      ADC_SDO      => LTC_ADC_SDO
    );

  -- Seuillage combinatoire
  -- Si les LEDs réagissent à l'envers sur la ligne noire,
  -- remplace simplement '>' par '<' dans les 7 comparaisons.
  process(data0r_s, data1r_s, data2r_s, data3r_s, data4r_s, data5r_s, data6r_s, sw_ext)
  begin
    if unsigned(data0r_s) > unsigned(sw_ext) then
      vect_capt_s(0) <= '1';
    else
      vect_capt_s(0) <= '0';
    end if;

    if unsigned(data1r_s) > unsigned(sw_ext) then
      vect_capt_s(1) <= '1';
    else
      vect_capt_s(1) <= '0';
    end if;

    if unsigned(data2r_s) > unsigned(sw_ext) then
      vect_capt_s(2) <= '1';
    else
      vect_capt_s(2) <= '0';
    end if;

    if unsigned(data3r_s) > unsigned(sw_ext) then
      vect_capt_s(3) <= '1';
    else
      vect_capt_s(3) <= '0';
    end if;

    if unsigned(data4r_s) > unsigned(sw_ext) then
      vect_capt_s(4) <= '1';
    else
      vect_capt_s(4) <= '0';
    end if;

    if unsigned(data5r_s) > unsigned(sw_ext) then
      vect_capt_s(5) <= '1';
    else
      vect_capt_s(5) <= '0';
    end if;

    if unsigned(data6r_s) > unsigned(sw_ext) then
      vect_capt_s(6) <= '1';
    else
      vect_capt_s(6) <= '0';
    end if;
  end process;

  -- Calcul combinatoire de la position
  process(vect_capt_s)
    variable ppu       : integer;
    variable pdu       : integer;
    variable found_one : boolean;
    variable pos_i     : integer;
  begin
    if vect_capt_s = "0000000" then
      ligne_pres_s <= '0';
      pos_ligne_s  <= to_signed(0, 4);
    else
      ligne_pres_s <= '1';

      found_one := false;
      ppu := 0;
      for i in 0 to 6 loop
        if (vect_capt_s(i) = '1') and (found_one = false) then
          ppu := i;
          found_one := true;
        end if;
      end loop;

      found_one := false;
      pdu := 0;
      for i in 6 downto 0 loop
        if (vect_capt_s(i) = '1') and (found_one = false) then
          pdu := i;
          found_one := true;
        end if;
      end loop;

      pos_i := ppu + pdu - 6;
      pos_ligne_s <= to_signed(pos_i, 4);
    end if;
  end process;

  -- Pack vers le Nios
  pos_to_nios(3 downto 0) <= std_logic_vector(pos_ligne_s);
  pos_to_nios(4)          <= ligne_pres_s;
  pos_to_nios(6 downto 5) <= "00";

  -- LEDs de debug
  LED(6 downto 0) <= vect_capt_s;
  LED(7)          <= ligne_pres_s;

  u0 : system
    port map (
      leds_export        => led_nios,
      switches_export    => sw_ext,
      clk_clk            => CLOCK_50,
      reset_reset_n      => rst_n,

      sdram_wire_addr    => DRAM_ADDR,
      sdram_wire_ba      => DRAM_BA,
      sdram_wire_cas_n   => DRAM_CAS_N,
      sdram_wire_cke     => DRAM_CKE,
      sdram_wire_cs_n    => DRAM_CS_N,
      sdram_wire_dq      => DRAM_DQ,
      sdram_wire_dqm     => DRAM_DQM,
      sdram_wire_ras_n   => DRAM_RAS_N,
      sdram_wire_we_n    => DRAM_WE_N,
      sdram_clk_clk      => DRAM_CLK,

      motor_right_export => motor_right_dummy,
      motor_left_export  => motor_left_dummy,

      pos_export         => pos_to_nios,

      data0r_pio_export  => data0r_s,
      data1r_pio_export  => data1r_s,
      data2r_pio_export  => data2r_s,
      data3r_pio_export  => data3r_s,
      data4r_pio_export  => data4r_s,
      data5r_pio_export  => data5r_s,
      data6r_pio_export  => data6r_s
    );

end architecture;