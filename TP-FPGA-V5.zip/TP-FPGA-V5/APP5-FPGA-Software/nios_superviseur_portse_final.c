#include <stdint.h>

/*
 * Version sans system.h et sans altera_avalon_pio_regs.h
 * Compatible avec un projet compilé directement dans Monitor Program.
 *
 * Mapping Qsys retenu :
 *   PORT_S_BASE = 0x00B0
 *   PORT_E_BASE = 0x00A0
 *
 * port_s(0) = start_sl
 * port_s(1) = start_rot
 * port_s(2) = dir_rot
 *
 * port_e(0) = fin_sl
 * port_e(1) = fin_rot
 * port_e(5:2) = pos_ligne (signé sur 4 bits)
 * port_e(6) = ligne_pres
 */

#define PORT_E_BASE 0x000000A0u
#define PORT_S_BASE 0x000000B0u

#define REG32(addr) (*(volatile uint32_t *)(addr))
#define IORD_32DIRECT(base, offset) REG32((base) + (offset))
#define IOWR_32DIRECT(base, offset, data) (REG32((base) + (offset)) = (uint32_t)(data))

#define PORT_S_START_SL_MASK   (1u << 0)
#define PORT_S_START_ROT_MASK  (1u << 1)
#define PORT_S_DIR_ROT_MASK    (1u << 2)

#define PORT_E_FIN_SL_MASK     (1u << 0)
#define PORT_E_FIN_ROT_MASK    (1u << 1)
#define PORT_E_POS_SHIFT       2
#define PORT_E_POS_MASK        (0xFu << PORT_E_POS_SHIFT)
#define PORT_E_LIGNE_PRES_MASK (1u << 6)

typedef enum
{
    ST_WAIT_LINE = 0,
    ST_START_SL,
    ST_RUN_SL,
    ST_STOP_1,
    ST_START_ROT,
    ST_RUN_ROT,
    ST_STOP_2
} robot_state_t;

static void busy_delay_cycles(volatile uint32_t cycles)
{
    while (cycles--)
    {
        __asm__("nop");
    }
}

static void delay_ms(uint32_t ms)
{
    /* Approximation pour Nios à ~50 MHz.
       1 ms ~= 12500 itérations avec la boucle ci-dessous. */
    while (ms--)
    {
        busy_delay_cycles(12500u);
    }
}

static inline void write_port_s(uint8_t start_sl, uint8_t start_rot, uint8_t dir_rot)
{
    uint32_t v = 0u;

    if (start_sl)
        v |= PORT_S_START_SL_MASK;
    if (start_rot)
        v |= PORT_S_START_ROT_MASK;
    if (dir_rot)
        v |= PORT_S_DIR_ROT_MASK;

    IOWR_32DIRECT(PORT_S_BASE, 0, v);
}

static inline uint32_t read_port_e_raw(void)
{
    return IORD_32DIRECT(PORT_E_BASE, 0);
}

static inline uint8_t read_fin_sl(uint32_t pe)
{
    return (pe & PORT_E_FIN_SL_MASK) ? 1u : 0u;
}

static inline uint8_t read_fin_rot(uint32_t pe)
{
    return (pe & PORT_E_FIN_ROT_MASK) ? 1u : 0u;
}

static inline uint8_t read_ligne_pres(uint32_t pe)
{
    return (pe & PORT_E_LIGNE_PRES_MASK) ? 1u : 0u;
}

static inline int8_t read_pos_ligne(uint32_t pe)
{
    uint8_t raw4 = (uint8_t)((pe & PORT_E_POS_MASK) >> PORT_E_POS_SHIFT);

    /* extension de signe 4 bits -> 8 bits */
    if (raw4 & 0x8u)
        raw4 |= 0xF0u;

    return (int8_t)raw4;
}

int main(void)
{
    robot_state_t state = ST_WAIT_LINE;

    /* 0 = droite, 1 = gauche */
    uint8_t last_dir_rot = 0u;

    /* mémoire de la dernière position utile vue avant perte de ligne */
    int8_t last_pos_valid = 0;
    int8_t last_nonzero_pos = 0;
    uint8_t have_last_nonzero_pos = 0u;

    write_port_s(0u, 0u, last_dir_rot);

    while (1)
    {
        uint32_t pe = read_port_e_raw();
        uint8_t ligne_pres = read_ligne_pres(pe);
        uint8_t fin_sl = read_fin_sl(pe);
        uint8_t fin_rot = read_fin_rot(pe);
        int8_t pos_ligne = read_pos_ligne(pe);

        /* Mémorisation de la dernière position connue tant que la ligne est présente */
        if (ligne_pres)
        {
            last_pos_valid = pos_ligne;

            if (pos_ligne != 0)
            {
                last_nonzero_pos = pos_ligne;
                have_last_nonzero_pos = 1u;
            }
        }

        switch (state)
        {
        case ST_WAIT_LINE:
            write_port_s(0u, 0u, last_dir_rot);
            if (ligne_pres)
            {
                state = ST_START_SL;
            }
            break;

        case ST_START_SL:
            /* ordre de départ du suivi de ligne */
            write_port_s(1u, 0u, last_dir_rot);
            delay_ms(20u);
            state = ST_RUN_SL;
            break;

        case ST_RUN_SL:
            /* maintien du suivi actif */
            write_port_s(1u, 0u, last_dir_rot);
            if (fin_sl)
            {
                write_port_s(0u, 0u, last_dir_rot);
                state = ST_STOP_1;
            }
            break;

        case ST_STOP_1:
            write_port_s(0u, 0u, last_dir_rot);

            /*
             * Choix du sens de rotation à partir de la dernière position
             * réellement observée AVANT la perte de ligne.
             *
             * Convention retenue :
             *   pos_ligne < 0  -> ligne à droite  -> rotation à droite
             *   pos_ligne > 0  -> ligne à gauche  -> rotation à gauche
             *
             * Si la dernière valeur était exactement 0, on conserve le
             * dernier sens connu au lieu d'alterner aléatoirement.
             */
            if (have_last_nonzero_pos)
            {
                if (last_nonzero_pos < 0)
                {
                    last_dir_rot = 0u; /* droite */
                }
                else
                {
                    last_dir_rot = 1u; /* gauche */
                }
            }
            else
            {
                if (last_pos_valid < 0)
                {
                    last_dir_rot = 0u; /* droite */
                }
                else if (last_pos_valid > 0)
                {
                    last_dir_rot = 1u; /* gauche */
                }
                else
                {
                    /* aucune info exploitable : on garde le dernier sens */
                }
            }

            delay_ms(1000u);
            state = ST_START_ROT;
            break;

        case ST_START_ROT:
            write_port_s(0u, 1u, last_dir_rot);
            delay_ms(20u);
            state = ST_RUN_ROT;
            break;

        case ST_RUN_ROT:
            write_port_s(0u, 1u, last_dir_rot);
            if (fin_rot)
            {
                write_port_s(0u, 0u, last_dir_rot);
                state = ST_STOP_2;
            }
            break;

        case ST_STOP_2:
            write_port_s(0u, 0u, last_dir_rot);
            delay_ms(1000u);

            /* on repart proprement pour la prochaine séquence */
            have_last_nonzero_pos = 0u;
            last_pos_valid = 0;
            last_nonzero_pos = 0;

            state = ST_WAIT_LINE;
            break;

        default:
            write_port_s(0u, 0u, last_dir_rot);
            state = ST_WAIT_LINE;
            break;
        }
    }

    return 0;
}