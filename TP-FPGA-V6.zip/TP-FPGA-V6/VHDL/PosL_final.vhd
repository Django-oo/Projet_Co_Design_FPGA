library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity PosL is
  port (
    val_capteurs : in  std_logic_vector(6 downto 0);
    ligne_pres   : out std_logic;
    pos_ligne    : out signed(3 downto 0);
    pos_export   : out std_logic_vector(6 downto 0)
  );
end entity;

architecture rtl of PosL is
  signal ligne_pres_s : std_logic := '0';
  signal pos_ligne_s  : signed(3 downto 0) := (others => '0');
begin
  ligne_pres <= ligne_pres_s;
  pos_ligne  <= pos_ligne_s;

  process(val_capteurs)
    variable ppu         : integer;
    variable pdu         : integer;
    variable pos_i       : integer;
    variable found_first : boolean;
    variable found_last  : boolean;
  begin
    if val_capteurs = "0000000" then
      ligne_pres_s <= '0';
      pos_ligne_s  <= to_signed(0, 4);

    else
      ligne_pres_s <= '1';

      ppu := 0;
      found_first := false;
      for i in 0 to 6 loop
        if (val_capteurs(i) = '1') and (not found_first) then
          ppu := i;
          found_first := true;
        end if;
      end loop;

      pdu := 0;
      found_last := false;
      for i in 6 downto 0 loop
        if (val_capteurs(i) = '1') and (not found_last) then
          pdu := i;
          found_last := true;
        end if;
      end loop;

      pos_i := ppu + pdu - 6;
      pos_ligne_s <= to_signed(pos_i, 4);
    end if;
  end process;

  pos_export(3 downto 0) <= std_logic_vector(pos_ligne_s);
  pos_export(4)          <= ligne_pres_s;
  pos_export(6 downto 5) <= "00";

end architecture;