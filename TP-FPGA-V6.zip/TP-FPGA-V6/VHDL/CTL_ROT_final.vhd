library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity CTL_ROT is
  generic (
    PWM_MAX      : integer := 3125;
    TURN_SPEED   : integer := 1100;
    CENTER_SPEED : integer := 1100;
    CENTER_TOL   : integer := 1;
    STABLE_COUNT : integer := 4
  );
  port (
    clk          : in  std_logic;
    reset_n      : in  std_logic;
    start_rot    : in  std_logic;
    dir_rot      : in  std_logic;  -- 0 = droite, 1 = gauche
    ligne_pres   : in  std_logic;
    pos_ligne    : in  signed(3 downto 0);
    fin_rot      : out std_logic;
    moteur_r_cmd : out std_logic_vector(13 downto 0);
    moteur_l_cmd : out std_logic_vector(13 downto 0)
  );
end entity;

architecture rtl of CTL_ROT is

  type state_t is (IDLE, SEARCH_LINE, CENTER_LINE, DONE);
  subtype cmd_t is std_logic_vector(13 downto 0);

  signal state_s      : state_t := IDLE;
  signal fin_rot_s    : std_logic := '0';
  signal moteur_r_s   : cmd_t := (others => '0');
  signal moteur_l_s   : cmd_t := (others => '0');
  signal centered_cnt : integer range 0 to STABLE_COUNT := 0;

  function clamp_pwm(v : integer) return integer is
  begin
    if v < 0 then
      return 0;
    elsif v > PWM_MAX then
      return PWM_MAX;
    else
      return v;
    end if;
  end function;

  function make_cmd(go_b : std_logic; dir_b : std_logic; speed_i : integer) return cmd_t is
    variable tmp : cmd_t := (others => '0');
    variable sat : integer;
  begin
    sat := clamp_pwm(speed_i);
    tmp(13) := go_b;
    tmp(12) := dir_b;
    tmp(11 downto 0) := std_logic_vector(to_unsigned(sat, 12));
    return tmp;
  end function;

  procedure rotate_on_place(
    signal mr : out cmd_t;
    signal ml : out cmd_t;
    constant direction : in std_logic;
    constant speed_i   : in integer
  ) is
  begin
    if direction = '0' then
      mr <= make_cmd('1', '1', speed_i); -- roue droite arrière
      ml <= make_cmd('1', '0', speed_i); -- roue gauche avant
    else
      mr <= make_cmd('1', '0', speed_i); -- roue droite avant
      ml <= make_cmd('1', '1', speed_i); -- roue gauche arrière
    end if;
  end procedure;

  procedure stop_motors(
    signal mr : out cmd_t;
    signal ml : out cmd_t
  ) is
  begin
    mr <= (others => '0');
    ml <= (others => '0');
  end procedure;

begin

  fin_rot      <= fin_rot_s;
  moteur_r_cmd <= moteur_r_s;
  moteur_l_cmd <= moteur_l_s;

  process(clk, reset_n)
    variable pos_i : integer;
  begin
    if reset_n = '0' then
      state_s      <= IDLE;
      fin_rot_s    <= '0';
      moteur_r_s   <= (others => '0');
      moteur_l_s   <= (others => '0');
      centered_cnt <= 0;

    elsif rising_edge(clk) then
      pos_i := to_integer(pos_ligne);

      case state_s is

        when IDLE =>
          fin_rot_s    <= '0';
          centered_cnt <= 0;
          stop_motors(moteur_r_s, moteur_l_s);

          if start_rot = '1' then
            state_s <= SEARCH_LINE;
          end if;

        when SEARCH_LINE =>
          fin_rot_s    <= '0';
          centered_cnt <= 0;

          if start_rot = '0' then
            state_s <= IDLE;
            stop_motors(moteur_r_s, moteur_l_s);

          elsif ligne_pres = '0' then
            rotate_on_place(moteur_r_s, moteur_l_s, dir_rot, TURN_SPEED);

          else
            state_s <= CENTER_LINE;
            stop_motors(moteur_r_s, moteur_l_s);
          end if;

        when CENTER_LINE =>
          fin_rot_s <= '0';

          if start_rot = '0' then
            state_s      <= IDLE;
            centered_cnt <= 0;
            stop_motors(moteur_r_s, moteur_l_s);

          elsif ligne_pres = '0' then
            state_s      <= SEARCH_LINE;
            centered_cnt <= 0;
            rotate_on_place(moteur_r_s, moteur_l_s, dir_rot, TURN_SPEED);

          else
            if pos_i > CENTER_TOL then
              rotate_on_place(moteur_r_s, moteur_l_s, '1', CENTER_SPEED);
              centered_cnt <= 0;

            elsif pos_i < -CENTER_TOL then
              rotate_on_place(moteur_r_s, moteur_l_s, '0', CENTER_SPEED);
              centered_cnt <= 0;

            else
              stop_motors(moteur_r_s, moteur_l_s);

              if centered_cnt < STABLE_COUNT then
                centered_cnt <= centered_cnt + 1;
              end if;

              if centered_cnt = STABLE_COUNT - 1 then
                state_s      <= DONE;
                fin_rot_s    <= '1';
                centered_cnt <= 0;
              end if;
            end if;
          end if;

        when DONE =>
          fin_rot_s    <= '1';
          centered_cnt <= 0;
          stop_motors(moteur_r_s, moteur_l_s);

          if start_rot = '0' then
            state_s <= IDLE;
          end if;

      end case;
    end if;
  end process;

end architecture;