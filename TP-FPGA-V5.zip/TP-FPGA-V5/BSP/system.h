/*
 * system.h - SOPC Builder system and BSP software package information
 *
 * Machine generated for CPU 'nios2_processor' in SOPC Builder design 'system'
 * SOPC Builder design path: C:/Users/mfacchi/FPGA/OneDrive_1_09-02-2026-TP3bis/OneDrive_1_09-02-2026/TP-FPGA/system.sopcinfo
 *
 * Generated: Mon Mar 09 11:02:26 CET 2026
 */

/*
 * DO NOT MODIFY THIS FILE
 *
 * Changing this file will have subtle consequences
 * which will almost certainly lead to a nonfunctioning
 * system. If you do modify this file, be aware that your
 * changes will be overwritten and lost when this file
 * is generated again.
 *
 * DO NOT MODIFY THIS FILE
 */

/*
 * License Agreement
 *
 * Copyright (c) 2008
 * Altera Corporation, San Jose, California, USA.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This agreement shall be governed in all respects by the laws of the State
 * of California and by the laws of the United States of America.
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/* Include definitions from linker script generator */
#include "linker.h"


/*
 * CPU configuration
 *
 */

#define ALT_CPU_ARCHITECTURE "altera_nios2_qsys"
#define ALT_CPU_BIG_ENDIAN 0
#define ALT_CPU_BREAK_ADDR 0x4002820
#define ALT_CPU_CPU_FREQ 50000000u
#define ALT_CPU_CPU_ID_SIZE 1
#define ALT_CPU_CPU_ID_VALUE 0x00000000
#define ALT_CPU_CPU_IMPLEMENTATION "tiny"
#define ALT_CPU_DATA_ADDR_WIDTH 0x1b
#define ALT_CPU_DCACHE_LINE_SIZE 0
#define ALT_CPU_DCACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_DCACHE_SIZE 0
#define ALT_CPU_EXCEPTION_ADDR 0x2000020
#define ALT_CPU_FLUSHDA_SUPPORTED
#define ALT_CPU_FREQ 50000000
#define ALT_CPU_HARDWARE_DIVIDE_PRESENT 0
#define ALT_CPU_HARDWARE_MULTIPLY_PRESENT 0
#define ALT_CPU_HARDWARE_MULX_PRESENT 0
#define ALT_CPU_HAS_DEBUG_CORE 1
#define ALT_CPU_HAS_DEBUG_STUB
#define ALT_CPU_HAS_JMPI_INSTRUCTION
#define ALT_CPU_ICACHE_LINE_SIZE 0
#define ALT_CPU_ICACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_ICACHE_SIZE 0
#define ALT_CPU_INST_ADDR_WIDTH 0x1b
#define ALT_CPU_NAME "nios2_processor"
#define ALT_CPU_RESET_ADDR 0x2000000


/*
 * CPU configuration (with legacy prefix - don't use these anymore)
 *
 */

#define NIOS2_BIG_ENDIAN 0
#define NIOS2_BREAK_ADDR 0x4002820
#define NIOS2_CPU_FREQ 50000000u
#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0x00000000
#define NIOS2_CPU_IMPLEMENTATION "tiny"
#define NIOS2_DATA_ADDR_WIDTH 0x1b
#define NIOS2_DCACHE_LINE_SIZE 0
#define NIOS2_DCACHE_LINE_SIZE_LOG2 0
#define NIOS2_DCACHE_SIZE 0
#define NIOS2_EXCEPTION_ADDR 0x2000020
#define NIOS2_FLUSHDA_SUPPORTED
#define NIOS2_HARDWARE_DIVIDE_PRESENT 0
#define NIOS2_HARDWARE_MULTIPLY_PRESENT 0
#define NIOS2_HARDWARE_MULX_PRESENT 0
#define NIOS2_HAS_DEBUG_CORE 1
#define NIOS2_HAS_DEBUG_STUB
#define NIOS2_HAS_JMPI_INSTRUCTION
#define NIOS2_ICACHE_LINE_SIZE 0
#define NIOS2_ICACHE_LINE_SIZE_LOG2 0
#define NIOS2_ICACHE_SIZE 0
#define NIOS2_INST_ADDR_WIDTH 0x1b
#define NIOS2_RESET_ADDR 0x2000000


/*
 * Define for each module class mastered by the CPU
 *
 */

#define __ALTERA_AVALON_JTAG_UART
#define __ALTERA_AVALON_NEW_SDRAM_CONTROLLER
#define __ALTERA_AVALON_ONCHIP_MEMORY2
#define __ALTERA_AVALON_PIO
#define __ALTERA_NIOS2_QSYS


/*
 * LEDS configuration
 *
 */

#define ALT_MODULE_CLASS_LEDS altera_avalon_pio
#define LEDS_BASE 0x4003010
#define LEDS_BIT_CLEARING_EDGE_REGISTER 0
#define LEDS_BIT_MODIFYING_OUTPUT_REGISTER 0
#define LEDS_CAPTURE 0
#define LEDS_DATA_WIDTH 8
#define LEDS_DO_TEST_BENCH_WIRING 0
#define LEDS_DRIVEN_SIM_VALUE 0
#define LEDS_EDGE_TYPE "NONE"
#define LEDS_FREQ 50000000
#define LEDS_HAS_IN 0
#define LEDS_HAS_OUT 1
#define LEDS_HAS_TRI 0
#define LEDS_IRQ -1
#define LEDS_IRQ_INTERRUPT_CONTROLLER_ID -1
#define LEDS_IRQ_TYPE "NONE"
#define LEDS_NAME "/dev/LEDS"
#define LEDS_RESET_VALUE 0
#define LEDS_SPAN 16
#define LEDS_TYPE "altera_avalon_pio"


/*
 * System configuration
 *
 */

#define ALT_DEVICE_FAMILY "Cyclone IV E"
#define ALT_IRQ_BASE NULL
#define ALT_LOG_PORT "/dev/null"
#define ALT_LOG_PORT_BASE 0x0
#define ALT_LOG_PORT_DEV null
#define ALT_LOG_PORT_TYPE ""
#define ALT_NUM_EXTERNAL_INTERRUPT_CONTROLLERS 0
#define ALT_NUM_INTERNAL_INTERRUPT_CONTROLLERS 1
#define ALT_NUM_INTERRUPT_CONTROLLERS 1
#define ALT_STDERR "/dev/jtag_uart"
#define ALT_STDERR_BASE 0x4003020
#define ALT_STDERR_DEV jtag_uart
#define ALT_STDERR_IS_JTAG_UART
#define ALT_STDERR_PRESENT
#define ALT_STDERR_TYPE "altera_avalon_jtag_uart"
#define ALT_STDIN "/dev/jtag_uart"
#define ALT_STDIN_BASE 0x4003020
#define ALT_STDIN_DEV jtag_uart
#define ALT_STDIN_IS_JTAG_UART
#define ALT_STDIN_PRESENT
#define ALT_STDIN_TYPE "altera_avalon_jtag_uart"
#define ALT_STDOUT "/dev/jtag_uart"
#define ALT_STDOUT_BASE 0x4003020
#define ALT_STDOUT_DEV jtag_uart
#define ALT_STDOUT_IS_JTAG_UART
#define ALT_STDOUT_PRESENT
#define ALT_STDOUT_TYPE "altera_avalon_jtag_uart"
#define ALT_SYSTEM_NAME "system"


/*
 * data0r configuration
 *
 */

#define ALT_MODULE_CLASS_data0r altera_avalon_pio
#define DATA0R_BASE 0x90
#define DATA0R_BIT_CLEARING_EDGE_REGISTER 0
#define DATA0R_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA0R_CAPTURE 0
#define DATA0R_DATA_WIDTH 8
#define DATA0R_DO_TEST_BENCH_WIRING 0
#define DATA0R_DRIVEN_SIM_VALUE 0
#define DATA0R_EDGE_TYPE "NONE"
#define DATA0R_FREQ 50000000
#define DATA0R_HAS_IN 1
#define DATA0R_HAS_OUT 0
#define DATA0R_HAS_TRI 0
#define DATA0R_IRQ -1
#define DATA0R_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA0R_IRQ_TYPE "NONE"
#define DATA0R_NAME "/dev/data0r"
#define DATA0R_RESET_VALUE 0
#define DATA0R_SPAN 16
#define DATA0R_TYPE "altera_avalon_pio"


/*
 * data1r configuration
 *
 */

#define ALT_MODULE_CLASS_data1r altera_avalon_pio
#define DATA1R_BASE 0x80
#define DATA1R_BIT_CLEARING_EDGE_REGISTER 0
#define DATA1R_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA1R_CAPTURE 0
#define DATA1R_DATA_WIDTH 8
#define DATA1R_DO_TEST_BENCH_WIRING 0
#define DATA1R_DRIVEN_SIM_VALUE 0
#define DATA1R_EDGE_TYPE "NONE"
#define DATA1R_FREQ 50000000
#define DATA1R_HAS_IN 1
#define DATA1R_HAS_OUT 0
#define DATA1R_HAS_TRI 0
#define DATA1R_IRQ -1
#define DATA1R_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA1R_IRQ_TYPE "NONE"
#define DATA1R_NAME "/dev/data1r"
#define DATA1R_RESET_VALUE 0
#define DATA1R_SPAN 16
#define DATA1R_TYPE "altera_avalon_pio"


/*
 * data2r configuration
 *
 */

#define ALT_MODULE_CLASS_data2r altera_avalon_pio
#define DATA2R_BASE 0x70
#define DATA2R_BIT_CLEARING_EDGE_REGISTER 0
#define DATA2R_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA2R_CAPTURE 0
#define DATA2R_DATA_WIDTH 8
#define DATA2R_DO_TEST_BENCH_WIRING 0
#define DATA2R_DRIVEN_SIM_VALUE 0
#define DATA2R_EDGE_TYPE "NONE"
#define DATA2R_FREQ 50000000
#define DATA2R_HAS_IN 1
#define DATA2R_HAS_OUT 0
#define DATA2R_HAS_TRI 0
#define DATA2R_IRQ -1
#define DATA2R_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA2R_IRQ_TYPE "NONE"
#define DATA2R_NAME "/dev/data2r"
#define DATA2R_RESET_VALUE 0
#define DATA2R_SPAN 16
#define DATA2R_TYPE "altera_avalon_pio"


/*
 * data3r configuration
 *
 */

#define ALT_MODULE_CLASS_data3r altera_avalon_pio
#define DATA3R_BASE 0x60
#define DATA3R_BIT_CLEARING_EDGE_REGISTER 0
#define DATA3R_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA3R_CAPTURE 0
#define DATA3R_DATA_WIDTH 8
#define DATA3R_DO_TEST_BENCH_WIRING 0
#define DATA3R_DRIVEN_SIM_VALUE 0
#define DATA3R_EDGE_TYPE "NONE"
#define DATA3R_FREQ 50000000
#define DATA3R_HAS_IN 1
#define DATA3R_HAS_OUT 0
#define DATA3R_HAS_TRI 0
#define DATA3R_IRQ -1
#define DATA3R_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA3R_IRQ_TYPE "NONE"
#define DATA3R_NAME "/dev/data3r"
#define DATA3R_RESET_VALUE 0
#define DATA3R_SPAN 16
#define DATA3R_TYPE "altera_avalon_pio"


/*
 * data4r configuration
 *
 */

#define ALT_MODULE_CLASS_data4r altera_avalon_pio
#define DATA4R_BASE 0x50
#define DATA4R_BIT_CLEARING_EDGE_REGISTER 0
#define DATA4R_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA4R_CAPTURE 0
#define DATA4R_DATA_WIDTH 8
#define DATA4R_DO_TEST_BENCH_WIRING 0
#define DATA4R_DRIVEN_SIM_VALUE 0
#define DATA4R_EDGE_TYPE "NONE"
#define DATA4R_FREQ 50000000
#define DATA4R_HAS_IN 1
#define DATA4R_HAS_OUT 0
#define DATA4R_HAS_TRI 0
#define DATA4R_IRQ -1
#define DATA4R_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA4R_IRQ_TYPE "NONE"
#define DATA4R_NAME "/dev/data4r"
#define DATA4R_RESET_VALUE 0
#define DATA4R_SPAN 16
#define DATA4R_TYPE "altera_avalon_pio"


/*
 * data5r configuration
 *
 */

#define ALT_MODULE_CLASS_data5r altera_avalon_pio
#define DATA5R_BASE 0x40
#define DATA5R_BIT_CLEARING_EDGE_REGISTER 0
#define DATA5R_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA5R_CAPTURE 0
#define DATA5R_DATA_WIDTH 8
#define DATA5R_DO_TEST_BENCH_WIRING 0
#define DATA5R_DRIVEN_SIM_VALUE 0
#define DATA5R_EDGE_TYPE "NONE"
#define DATA5R_FREQ 50000000
#define DATA5R_HAS_IN 1
#define DATA5R_HAS_OUT 0
#define DATA5R_HAS_TRI 0
#define DATA5R_IRQ -1
#define DATA5R_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA5R_IRQ_TYPE "NONE"
#define DATA5R_NAME "/dev/data5r"
#define DATA5R_RESET_VALUE 0
#define DATA5R_SPAN 16
#define DATA5R_TYPE "altera_avalon_pio"


/*
 * data6r configuration
 *
 */

#define ALT_MODULE_CLASS_data6r altera_avalon_pio
#define DATA6R_BASE 0x30
#define DATA6R_BIT_CLEARING_EDGE_REGISTER 0
#define DATA6R_BIT_MODIFYING_OUTPUT_REGISTER 0
#define DATA6R_CAPTURE 0
#define DATA6R_DATA_WIDTH 8
#define DATA6R_DO_TEST_BENCH_WIRING 0
#define DATA6R_DRIVEN_SIM_VALUE 0
#define DATA6R_EDGE_TYPE "NONE"
#define DATA6R_FREQ 50000000
#define DATA6R_HAS_IN 1
#define DATA6R_HAS_OUT 0
#define DATA6R_HAS_TRI 0
#define DATA6R_IRQ -1
#define DATA6R_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DATA6R_IRQ_TYPE "NONE"
#define DATA6R_NAME "/dev/data6r"
#define DATA6R_RESET_VALUE 0
#define DATA6R_SPAN 16
#define DATA6R_TYPE "altera_avalon_pio"


/*
 * hal configuration
 *
 */

#define ALT_MAX_FD 32
#define ALT_SYS_CLK none
#define ALT_TIMESTAMP_CLK none


/*
 * jtag_uart configuration
 *
 */

#define ALT_MODULE_CLASS_jtag_uart altera_avalon_jtag_uart
#define JTAG_UART_BASE 0x4003020
#define JTAG_UART_IRQ -1
#define JTAG_UART_IRQ_INTERRUPT_CONTROLLER_ID -1
#define JTAG_UART_NAME "/dev/jtag_uart"
#define JTAG_UART_READ_DEPTH 64
#define JTAG_UART_READ_THRESHOLD 8
#define JTAG_UART_SPAN 8
#define JTAG_UART_TYPE "altera_avalon_jtag_uart"
#define JTAG_UART_WRITE_DEPTH 64
#define JTAG_UART_WRITE_THRESHOLD 8


/*
 * motor_left configuration
 *
 */

#define ALT_MODULE_CLASS_motor_left altera_avalon_pio
#define MOTOR_LEFT_BASE 0x0
#define MOTOR_LEFT_BIT_CLEARING_EDGE_REGISTER 0
#define MOTOR_LEFT_BIT_MODIFYING_OUTPUT_REGISTER 0
#define MOTOR_LEFT_CAPTURE 0
#define MOTOR_LEFT_DATA_WIDTH 14
#define MOTOR_LEFT_DO_TEST_BENCH_WIRING 0
#define MOTOR_LEFT_DRIVEN_SIM_VALUE 0
#define MOTOR_LEFT_EDGE_TYPE "NONE"
#define MOTOR_LEFT_FREQ 50000000
#define MOTOR_LEFT_HAS_IN 0
#define MOTOR_LEFT_HAS_OUT 1
#define MOTOR_LEFT_HAS_TRI 0
#define MOTOR_LEFT_IRQ -1
#define MOTOR_LEFT_IRQ_INTERRUPT_CONTROLLER_ID -1
#define MOTOR_LEFT_IRQ_TYPE "NONE"
#define MOTOR_LEFT_NAME "/dev/motor_left"
#define MOTOR_LEFT_RESET_VALUE 0
#define MOTOR_LEFT_SPAN 16
#define MOTOR_LEFT_TYPE "altera_avalon_pio"


/*
 * motor_right configuration
 *
 */

#define ALT_MODULE_CLASS_motor_right altera_avalon_pio
#define MOTOR_RIGHT_BASE 0x10
#define MOTOR_RIGHT_BIT_CLEARING_EDGE_REGISTER 0
#define MOTOR_RIGHT_BIT_MODIFYING_OUTPUT_REGISTER 0
#define MOTOR_RIGHT_CAPTURE 0
#define MOTOR_RIGHT_DATA_WIDTH 14
#define MOTOR_RIGHT_DO_TEST_BENCH_WIRING 0
#define MOTOR_RIGHT_DRIVEN_SIM_VALUE 0
#define MOTOR_RIGHT_EDGE_TYPE "NONE"
#define MOTOR_RIGHT_FREQ 50000000
#define MOTOR_RIGHT_HAS_IN 0
#define MOTOR_RIGHT_HAS_OUT 1
#define MOTOR_RIGHT_HAS_TRI 0
#define MOTOR_RIGHT_IRQ -1
#define MOTOR_RIGHT_IRQ_INTERRUPT_CONTROLLER_ID -1
#define MOTOR_RIGHT_IRQ_TYPE "NONE"
#define MOTOR_RIGHT_NAME "/dev/motor_right"
#define MOTOR_RIGHT_RESET_VALUE 0
#define MOTOR_RIGHT_SPAN 16
#define MOTOR_RIGHT_TYPE "altera_avalon_pio"


/*
 * onchip_memory configuration
 *
 */

#define ALT_MODULE_CLASS_onchip_memory altera_avalon_onchip_memory2
#define ONCHIP_MEMORY_ALLOW_IN_SYSTEM_MEMORY_CONTENT_EDITOR 0
#define ONCHIP_MEMORY_ALLOW_MRAM_SIM_CONTENTS_ONLY_FILE 0
#define ONCHIP_MEMORY_BASE 0x4001000
#define ONCHIP_MEMORY_CONTENTS_INFO ""
#define ONCHIP_MEMORY_DUAL_PORT 0
#define ONCHIP_MEMORY_GUI_RAM_BLOCK_TYPE "AUTO"
#define ONCHIP_MEMORY_INIT_CONTENTS_FILE "system_onchip_memory"
#define ONCHIP_MEMORY_INIT_MEM_CONTENT 1
#define ONCHIP_MEMORY_INSTANCE_ID "NONE"
#define ONCHIP_MEMORY_IRQ -1
#define ONCHIP_MEMORY_IRQ_INTERRUPT_CONTROLLER_ID -1
#define ONCHIP_MEMORY_NAME "/dev/onchip_memory"
#define ONCHIP_MEMORY_NON_DEFAULT_INIT_FILE_ENABLED 0
#define ONCHIP_MEMORY_RAM_BLOCK_TYPE "AUTO"
#define ONCHIP_MEMORY_READ_DURING_WRITE_MODE "DONT_CARE"
#define ONCHIP_MEMORY_SINGLE_CLOCK_OP 0
#define ONCHIP_MEMORY_SIZE_MULTIPLE 1
#define ONCHIP_MEMORY_SIZE_VALUE 4096
#define ONCHIP_MEMORY_SPAN 4096
#define ONCHIP_MEMORY_TYPE "altera_avalon_onchip_memory2"
#define ONCHIP_MEMORY_WRITABLE 1


/*
 * pos_pio configuration
 *
 */

#define ALT_MODULE_CLASS_pos_pio altera_avalon_pio
#define POS_PIO_BASE 0x20
#define POS_PIO_BIT_CLEARING_EDGE_REGISTER 0
#define POS_PIO_BIT_MODIFYING_OUTPUT_REGISTER 0
#define POS_PIO_CAPTURE 0
#define POS_PIO_DATA_WIDTH 7
#define POS_PIO_DO_TEST_BENCH_WIRING 0
#define POS_PIO_DRIVEN_SIM_VALUE 0
#define POS_PIO_EDGE_TYPE "NONE"
#define POS_PIO_FREQ 50000000
#define POS_PIO_HAS_IN 1
#define POS_PIO_HAS_OUT 0
#define POS_PIO_HAS_TRI 0
#define POS_PIO_IRQ -1
#define POS_PIO_IRQ_INTERRUPT_CONTROLLER_ID -1
#define POS_PIO_IRQ_TYPE "NONE"
#define POS_PIO_NAME "/dev/pos_pio"
#define POS_PIO_RESET_VALUE 0
#define POS_PIO_SPAN 16
#define POS_PIO_TYPE "altera_avalon_pio"


/*
 * sdram configuration
 *
 */

#define ALT_MODULE_CLASS_sdram altera_avalon_new_sdram_controller
#define SDRAM_BASE 0x2000000
#define SDRAM_CAS_LATENCY 3
#define SDRAM_CONTENTS_INFO
#define SDRAM_INIT_NOP_DELAY 0.0
#define SDRAM_INIT_REFRESH_COMMANDS 2
#define SDRAM_IRQ -1
#define SDRAM_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SDRAM_IS_INITIALIZED 1
#define SDRAM_NAME "/dev/sdram"
#define SDRAM_POWERUP_DELAY 100.0
#define SDRAM_REFRESH_PERIOD 15.625
#define SDRAM_REGISTER_DATA_IN 1
#define SDRAM_SDRAM_ADDR_WIDTH 0x18
#define SDRAM_SDRAM_BANK_WIDTH 2
#define SDRAM_SDRAM_COL_WIDTH 9
#define SDRAM_SDRAM_DATA_WIDTH 16
#define SDRAM_SDRAM_NUM_BANKS 4
#define SDRAM_SDRAM_NUM_CHIPSELECTS 1
#define SDRAM_SDRAM_ROW_WIDTH 13
#define SDRAM_SHARED_DATA 0
#define SDRAM_SIM_MODEL_BASE 0
#define SDRAM_SPAN 33554432
#define SDRAM_STARVATION_INDICATOR 0
#define SDRAM_TRISTATE_BRIDGE_SLAVE ""
#define SDRAM_TYPE "altera_avalon_new_sdram_controller"
#define SDRAM_T_AC 5.5
#define SDRAM_T_MRD 3
#define SDRAM_T_RCD 20.0
#define SDRAM_T_RFC 70.0
#define SDRAM_T_RP 20.0
#define SDRAM_T_WR 14.0


/*
 * switches configuration
 *
 */

#define ALT_MODULE_CLASS_switches altera_avalon_pio
#define SWITCHES_BASE 0x4003000
#define SWITCHES_BIT_CLEARING_EDGE_REGISTER 0
#define SWITCHES_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SWITCHES_CAPTURE 0
#define SWITCHES_DATA_WIDTH 8
#define SWITCHES_DO_TEST_BENCH_WIRING 0
#define SWITCHES_DRIVEN_SIM_VALUE 0
#define SWITCHES_EDGE_TYPE "NONE"
#define SWITCHES_FREQ 50000000
#define SWITCHES_HAS_IN 1
#define SWITCHES_HAS_OUT 0
#define SWITCHES_HAS_TRI 0
#define SWITCHES_IRQ -1
#define SWITCHES_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SWITCHES_IRQ_TYPE "NONE"
#define SWITCHES_NAME "/dev/switches"
#define SWITCHES_RESET_VALUE 0
#define SWITCHES_SPAN 16
#define SWITCHES_TYPE "altera_avalon_pio"

#endif /* __SYSTEM_H_ */
