#include <stdint.h>

#define PORT_E_BASE 0x000000A0u
#define PORT_S_BASE 0x000000B0u

#define REG32(addr) (*(volatile uint32_t *)(addr))
#define IORD_32DIRECT(base, offset) REG32((base) + (offset))
#define IOWR_32DIRECT(base, offset, data) (REG32((base) + (offset)) = (uint32_t)(data))

#define PORT_S_START_SL_MASK      (1u << 0)
#define PORT_S_START_ROT_MASK     (1u << 1)
#define PORT_S_DIR_ROT_MASK       (1u << 2)

#define PORT_E_FIN_SL_MASK        (1u << 0)
#define PORT_E_FIN_ROT_MASK       (1u << 1)
#define PORT_E_POS_SHIFT          2
#define PORT_E_POS_MASK           (0xFu << PORT_E_POS_SHIFT)
#define PORT_E_LIGNE_PRES_MASK    (1u << 6)

#define ROT_RIGHT 0u
#define ROT_LEFT  1u

#define STOP_BEFORE_ROT_MS     300u
#define STOP_BEFORE_SL_MS      300u
#define ROTATION_TIMEOUT_MS   12000u
#define LOOP_DELAY_MS             2u

typedef enum
{
    ST_WAIT_LINE = 0,
    ST_RUN_SL,
    ST_STOP_BEFORE_ROT,
    ST_RUN_ROT,
    ST_STOP_BEFORE_SL
} robot_state_t;

static void busy_delay_cycles(volatile uint32_t cycles)
{
    while (cycles--)
    {
        __asm__("nop");
    }
}

static void delay_ms(uint32_t ms)
{
    while (ms--)
    {
        busy_delay_cycles(12500u);
    }
}

static inline void write_port_s(uint8_t start_sl, uint8_t start_rot, uint8_t dir_rot)
{
    uint32_t v = 0u;

    if (start_sl)  v |= PORT_S_START_SL_MASK;
    if (start_rot) v |= PORT_S_START_ROT_MASK;
    if (dir_rot)   v |= PORT_S_DIR_ROT_MASK;

    IOWR_32DIRECT(PORT_S_BASE, 0, v);
}

static inline uint32_t read_port_e_raw(void)
{
    return IORD_32DIRECT(PORT_E_BASE, 0);
}

static inline uint8_t read_fin_sl(uint32_t pe)
{
    return (pe & PORT_E_FIN_SL_MASK) ? 1u : 0u;
}

static inline uint8_t read_fin_rot(uint32_t pe)
{
    return (pe & PORT_E_FIN_ROT_MASK) ? 1u : 0u;
}

static inline uint8_t read_ligne_pres(uint32_t pe)
{
    return (pe & PORT_E_LIGNE_PRES_MASK) ? 1u : 0u;
}

static inline int8_t read_pos_ligne(uint32_t pe)
{
    uint8_t raw4 = (uint8_t)((pe & PORT_E_POS_MASK) >> PORT_E_POS_SHIFT);

    if (raw4 & 0x8u)
    {
        raw4 |= 0xF0u;
    }

    return (int8_t)raw4;
}

static inline uint8_t toggle_rotation_dir(uint8_t dir_rot)
{
    return (dir_rot == ROT_RIGHT) ? ROT_LEFT : ROT_RIGHT;
}

int main(void)
{
    robot_state_t state = ST_WAIT_LINE;

    uint8_t last_dir_rot = ROT_RIGHT;
    uint32_t rot_timer_ms = 0u;

    write_port_s(0u, 0u, last_dir_rot);

    while (1)
    {
        uint32_t pe = read_port_e_raw();
        uint8_t ligne_pres = read_ligne_pres(pe);
        uint8_t fin_sl = read_fin_sl(pe);
        uint8_t fin_rot = read_fin_rot(pe);
        (void)read_pos_ligne(pe);

        switch (state)
        {
            case ST_WAIT_LINE:
                write_port_s(0u, 0u, last_dir_rot);

                if (ligne_pres)
                {
                    state = ST_RUN_SL;
                }
                break;

            case ST_RUN_SL:
                write_port_s(1u, 0u, last_dir_rot);

                if (fin_sl)
                {
                    write_port_s(0u, 0u, last_dir_rot);
                    state = ST_STOP_BEFORE_ROT;
                }
                break;

            case ST_STOP_BEFORE_ROT:
                write_port_s(0u, 0u, last_dir_rot);
                delay_ms(STOP_BEFORE_ROT_MS);

                rot_timer_ms = 0u;
                state = ST_RUN_ROT;
                break;

            case ST_RUN_ROT:
                write_port_s(0u, 1u, last_dir_rot);

                if (fin_rot)
                {
                    write_port_s(0u, 0u, last_dir_rot);

                    /* préparer le prochain demi-tour */
                    last_dir_rot = toggle_rotation_dir(last_dir_rot);

                    state = ST_STOP_BEFORE_SL;
                }
                else
                {
                    delay_ms(LOOP_DELAY_MS);
                    rot_timer_ms += LOOP_DELAY_MS;

                    if (rot_timer_ms >= ROTATION_TIMEOUT_MS)
                    {
                        write_port_s(0u, 0u, last_dir_rot);
                        delay_ms(100u);
                        rot_timer_ms = 0u;
                    }
                }
                break;

            case ST_STOP_BEFORE_SL:
                write_port_s(0u, 0u, last_dir_rot);
                delay_ms(STOP_BEFORE_SL_MS);

                if (read_ligne_pres(read_port_e_raw()))
                {
                    state = ST_RUN_SL;
                }
                else
                {
                    rot_timer_ms = 0u;
                    state = ST_RUN_ROT;
                }
                break;

            default:
                write_port_s(0u, 0u, last_dir_rot);
                state = ST_WAIT_LINE;
                break;
        }
    }

    return 0;
}