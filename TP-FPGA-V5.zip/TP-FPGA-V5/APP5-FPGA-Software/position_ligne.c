#include <stdint.h>

#define JTAG_UART_DATA    (*(volatile unsigned int *)0x04003020u)
#define JTAG_UART_CONTROL (*(volatile unsigned int *)0x04003024u)

#define DATA6_BASE 0x00000030u
#define DATA5_BASE 0x00000040u
#define DATA4_BASE 0x00000050u
#define DATA3_BASE 0x00000060u
#define DATA2_BASE 0x00000070u
#define DATA1_BASE 0x00000080u
#define DATA0_BASE 0x00000090u

static unsigned char mmio_read8(unsigned int addr)
{
    return *(volatile unsigned char *)addr;
}

static void putc_jtag(char c)
{
    while (((JTAG_UART_CONTROL >> 16) & 0xFFFFu) == 0u) {
    }
    JTAG_UART_DATA = (unsigned int)c;
}

static void puts_jtag(const char *s)
{
    while (*s != '\0') {
        putc_jtag(*s);
        s++;
    }
}

static void put_uint_jtag(unsigned int value)
{
    char buf[10];
    int i;

    if (value == 0u) {
        putc_jtag('0');
        return;
    }

    i = 0;
    while (value > 0u) {
        buf[i] = (char)('0' + (value % 10u));
        value = value / 10u;
        i++;
    }

    while (i > 0) {
        i--;
        putc_jtag(buf[i]);
    }
}

static void put_uint3_jtag(unsigned int value)
{
    if (value < 100u) {
        putc_jtag(' ');
    }
    if (value < 10u) {
        putc_jtag(' ');
    }
    put_uint_jtag(value);
}

static void delay_ms(unsigned int ms)
{
    volatile unsigned int i;
    volatile unsigned int j;
    const unsigned int LOOP_PER_MS = 5000u;

    for (j = 0u; j < ms; j++) {
        for (i = 0u; i < LOOP_PER_MS; i++) {
        }
    }
}

int main(void)
{
    unsigned char d0;
    unsigned char d1;
    unsigned char d2;
    unsigned char d3;
    unsigned char d4;
    unsigned char d5;
    unsigned char d6;

    while (1) {
        d0 = mmio_read8(DATA0_BASE);
        d1 = mmio_read8(DATA1_BASE);
        d2 = mmio_read8(DATA2_BASE);
        d3 = mmio_read8(DATA3_BASE);
        d4 = mmio_read8(DATA4_BASE);
        d5 = mmio_read8(DATA5_BASE);
        d6 = mmio_read8(DATA6_BASE);

        puts_jtag("d=[");
        put_uint3_jtag((unsigned int)d0);
        putc_jtag(' ');
        put_uint3_jtag((unsigned int)d1);
        putc_jtag(' ');
        put_uint3_jtag((unsigned int)d2);
        putc_jtag(' ');
        put_uint3_jtag((unsigned int)d3);
        putc_jtag(' ');
        put_uint3_jtag((unsigned int)d4);
        putc_jtag(' ');
        put_uint3_jtag((unsigned int)d5);
        putc_jtag(' ');
        put_uint3_jtag((unsigned int)d6);
        puts_jtag("]\r\n");

        delay_ms(200u);
    }

    return 0;
}