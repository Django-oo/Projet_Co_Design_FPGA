library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity position_ligne_nios_top is
  port (
    CLOCK_50 : in  std_logic;
    KEY      : in  std_logic_vector(1 downto 0);
    SW       : in  std_logic_vector(3 downto 0);
    LED      : out std_logic_vector(7 downto 0);

    DRAM_CLK   : out   std_logic;
    DRAM_CKE   : out   std_logic;
    DRAM_ADDR  : out   std_logic_vector(12 downto 0);
    DRAM_BA    : out   std_logic_vector(1 downto 0);
    DRAM_CS_N  : out   std_logic;
    DRAM_CAS_N : out   std_logic;
    DRAM_RAS_N : out   std_logic;
    DRAM_WE_N  : out   std_logic;
    DRAM_DQ    : inout std_logic_vector(15 downto 0);
    DRAM_DQM   : out   std_logic_vector(1 downto 0);

    MTRR_P : out std_logic;
    MTRR_N : out std_logic;
    MTRL_P : out std_logic;
    MTRL_N : out std_logic;

    MTR_Fault_n : in  std_logic;
    MTR_Sleep_n : out std_logic;

    LTC_ADC_CONVST : out std_logic;
    LTC_ADC_SCK    : out std_logic;
    LTC_ADC_SDI    : out std_logic;
    LTC_ADC_SDO    : in  std_logic;

    VCC3P3_PWRON_n : out std_logic
  );
end entity;

architecture Structure of position_ligne_nios_top is

  component system is
    port (
      leds_export        : out   std_logic_vector(7 downto 0);
      switches_export    : in    std_logic_vector(7 downto 0)  := (others => 'X');
      clk_clk            : in    std_logic                     := 'X';
      reset_reset_n      : in    std_logic                     := 'X';
      sdram_wire_addr    : out   std_logic_vector(12 downto 0);
      sdram_wire_ba      : out   std_logic_vector(1 downto 0);
      sdram_wire_cas_n   : out   std_logic;
      sdram_wire_cke     : out   std_logic;
      sdram_wire_cs_n    : out   std_logic;
      sdram_wire_dq      : inout std_logic_vector(15 downto 0) := (others => 'X');
      sdram_wire_dqm     : out   std_logic_vector(1 downto 0);
      sdram_wire_ras_n   : out   std_logic;
      sdram_wire_we_n    : out   std_logic;
      sdram_clk_clk      : out   std_logic;
      motor_right_export : out   std_logic_vector(13 downto 0);
      motor_left_export  : out   std_logic_vector(13 downto 0);
      pos_export         : in    std_logic_vector(6 downto 0)  := (others => 'X');
      data0r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data1r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data2r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data3r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data4r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data5r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      data6r_pio_export  : in    std_logic_vector(7 downto 0)  := (others => 'X');
      port_s_export      : out   std_logic_vector(2 downto 0);
      port_e_export      : in    std_logic_vector(7 downto 0)  := (others => 'X')
    );
  end component;

  component capteurs_sol is
    port (
      clk          : in  std_logic;
      reset_n      : in  std_logic;
      data_capture : in  std_logic;
      data_readyr  : out std_logic;
      data0r       : out std_logic_vector(7 downto 0);
      data1r       : out std_logic_vector(7 downto 0);
      data2r       : out std_logic_vector(7 downto 0);
      data3r       : out std_logic_vector(7 downto 0);
      data4r       : out std_logic_vector(7 downto 0);
      data5r       : out std_logic_vector(7 downto 0);
      data6r       : out std_logic_vector(7 downto 0);
      ADC_CONVSTr  : out std_logic;
      ADC_SCK      : out std_logic;
      ADC_SDIr     : out std_logic;
      ADC_SDO      : in  std_logic
    );
  end component;

  component pll_2freqs is
    port (
      areset : in  std_logic := '0';
      inclk0 : in  std_logic := '0';
      c0     : out std_logic;
      c1     : out std_logic
    );
  end component;

  component PWM_generation is
    port (
      clk           : in  std_logic;
      reset_n       : in  std_logic;
      s_writedataR  : in  std_logic_vector(13 downto 0);
      s_writedataL  : in  std_logic_vector(13 downto 0);
      dc_motor_p_R  : out std_logic;
      dc_motor_n_R  : out std_logic;
      dc_motor_p_L  : out std_logic;
      dc_motor_n_L  : out std_logic
    );
  end component;

  component PosL is
    port (
      val_capteurs : in  std_logic_vector(6 downto 0);
      ligne_pres   : out std_logic;
      pos_ligne    : out signed(3 downto 0);
      pos_export   : out std_logic_vector(6 downto 0)
    );
  end component;

  component CTL_SL is
    generic (
      PWM_MAX    : integer := 3125;
      BASE_SPEED : integer := 2000;
      MIN_SPEED  : integer := 250;
      TRIM_R     : integer := 0;
      TRIM_L     : integer := 0
    );
    port (
      clk          : in  std_logic;
      reset_n      : in  std_logic;
      start_sl     : in  std_logic;
      ligne_pres   : in  std_logic;
      pos_ligne    : in  signed(3 downto 0);
      fin_sl       : out std_logic;
      moteur_r_cmd : out std_logic_vector(13 downto 0);
      moteur_l_cmd : out std_logic_vector(13 downto 0)
    );
  end component;

  component CTL_ROT is
    generic (
      PWM_MAX      : integer := 3125;
      TURN_SPEED : integer := 2500;
      CENTER_SPEED : integer := 1500;
      CENTER_TOL   : integer := 1;
      STABLE_COUNT : integer := 3
    );
    port (
      clk          : in  std_logic;
      reset_n      : in  std_logic;
      start_rot    : in  std_logic;
      dir_rot      : in  std_logic;
      ligne_pres   : in  std_logic;
      pos_ligne    : in  signed(3 downto 0);
      fin_rot      : out std_logic;
      moteur_r_cmd : out std_logic_vector(13 downto 0);
      moteur_l_cmd : out std_logic_vector(13 downto 0)
    );
  end component;

  constant SEUIL_CAPTEURS : std_logic_vector(7 downto 0) := x"6E";

  signal rst_n         : std_logic;
  signal restart_req_s : std_logic;
  signal clk40         : std_logic;
  signal clk2k         : std_logic;
  signal sw_ext        : std_logic_vector(7 downto 0);
  signal led_nios      : std_logic_vector(7 downto 0);

  signal data0r_s      : std_logic_vector(7 downto 0);
  signal data1r_s      : std_logic_vector(7 downto 0);
  signal data2r_s      : std_logic_vector(7 downto 0);
  signal data3r_s      : std_logic_vector(7 downto 0);
  signal data4r_s      : std_logic_vector(7 downto 0);
  signal data5r_s      : std_logic_vector(7 downto 0);
  signal data6r_s      : std_logic_vector(7 downto 0);
  signal data_ready_s  : std_logic;

  signal vect_capt_s   : std_logic_vector(6 downto 0);
  signal ligne_pres_s  : std_logic;
  signal pos_ligne_s   : signed(3 downto 0);
  signal pos_to_nios_s : std_logic_vector(6 downto 0);

  signal port_s_s      : std_logic_vector(2 downto 0);
  signal port_e_s      : std_logic_vector(7 downto 0);

  signal start_sl_s    : std_logic;
  signal start_rot_s   : std_logic;
  signal dir_rot_s     : std_logic;
  signal fin_sl_s      : std_logic;
  signal fin_rot_s     : std_logic;

  signal cmd_r_sl_s    : std_logic_vector(13 downto 0);
  signal cmd_l_sl_s    : std_logic_vector(13 downto 0);
  signal cmd_r_rot_s   : std_logic_vector(13 downto 0);
  signal cmd_l_rot_s   : std_logic_vector(13 downto 0);
  signal cmd_r_mux_s   : std_logic_vector(13 downto 0);
  signal cmd_l_mux_s   : std_logic_vector(13 downto 0);

  signal motor_right_dummy : std_logic_vector(13 downto 0);
  signal motor_left_dummy  : std_logic_vector(13 downto 0);

begin

  rst_n         <= KEY(0);
  restart_req_s <= not KEY(1);
  sw_ext        <= SEUIL_CAPTEURS;

  VCC3P3_PWRON_n <= '0';
  MTR_Sleep_n    <= '1';

  start_sl_s  <= port_s_s(0);
  start_rot_s <= port_s_s(1);
  dir_rot_s   <= port_s_s(2);

  port_e_s(0) <= fin_sl_s;
  port_e_s(1) <= fin_rot_s;
  port_e_s(5 downto 2) <= std_logic_vector(pos_ligne_s);
  port_e_s(6) <= ligne_pres_s;
  port_e_s(7) <= restart_req_s;

  LED(6 downto 0) <= vect_capt_s;
  LED(7)          <= ligne_pres_s;

  u_pll : pll_2freqs
    port map (
      areset => not rst_n,
      inclk0 => CLOCK_50,
      c0     => clk40,
      c1     => clk2k
    );

  u_caps : capteurs_sol
    port map (
      clk          => clk40,
      reset_n      => rst_n,
      data_capture => clk2k,
      data_readyr  => data_ready_s,
      data0r       => data0r_s,
      data1r       => data1r_s,
      data2r       => data2r_s,
      data3r       => data3r_s,
      data4r       => data4r_s,
      data5r       => data5r_s,
      data6r       => data6r_s,
      ADC_CONVSTr  => LTC_ADC_CONVST,
      ADC_SCK      => LTC_ADC_SCK,
      ADC_SDIr     => LTC_ADC_SDI,
      ADC_SDO      => LTC_ADC_SDO
    );

  process(data0r_s, data1r_s, data2r_s, data3r_s, data4r_s, data5r_s, data6r_s, sw_ext)
  begin
    if unsigned(data0r_s) > unsigned(sw_ext) then vect_capt_s(0) <= '1'; else vect_capt_s(0) <= '0'; end if;
    if unsigned(data1r_s) > unsigned(sw_ext) then vect_capt_s(1) <= '1'; else vect_capt_s(1) <= '0'; end if;
    if unsigned(data2r_s) > unsigned(sw_ext) then vect_capt_s(2) <= '1'; else vect_capt_s(2) <= '0'; end if;
    if unsigned(data3r_s) > unsigned(sw_ext) then vect_capt_s(3) <= '1'; else vect_capt_s(3) <= '0'; end if;
    if unsigned(data4r_s) > unsigned(sw_ext) then vect_capt_s(4) <= '1'; else vect_capt_s(4) <= '0'; end if;
    if unsigned(data5r_s) > unsigned(sw_ext) then vect_capt_s(5) <= '1'; else vect_capt_s(5) <= '0'; end if;
    if unsigned(data6r_s) > unsigned(sw_ext) then vect_capt_s(6) <= '1'; else vect_capt_s(6) <= '0'; end if;
  end process;

  u_posl : PosL
    port map (
      val_capteurs => vect_capt_s,
      ligne_pres   => ligne_pres_s,
      pos_ligne    => pos_ligne_s,
      pos_export   => pos_to_nios_s
    );

  u_ctl_sl : CTL_SL
    generic map (
      PWM_MAX    => 3125,
      BASE_SPEED => 2000,
      MIN_SPEED  => 250,
      TRIM_R     => 0,
      TRIM_L     => 0
    )
    port map (
      clk          => CLOCK_50,
      reset_n      => rst_n,
      start_sl     => start_sl_s,
      ligne_pres   => ligne_pres_s,
      pos_ligne    => pos_ligne_s,
      fin_sl       => fin_sl_s,
      moteur_r_cmd => cmd_r_sl_s,
      moteur_l_cmd => cmd_l_sl_s
    );

  u_ctl_rot : CTL_ROT
    generic map (
      PWM_MAX      => 3125,
      TURN_SPEED => 2500,
      CENTER_SPEED => 1500,
      CENTER_TOL   => 1,
      STABLE_COUNT => 3
    )
    port map (
      clk          => CLOCK_50,
      reset_n      => rst_n,
      start_rot    => start_rot_s,
      dir_rot      => dir_rot_s,
      ligne_pres   => ligne_pres_s,
      pos_ligne    => pos_ligne_s,
      fin_rot      => fin_rot_s,
      moteur_r_cmd => cmd_r_rot_s,
      moteur_l_cmd => cmd_l_rot_s
    );

  process(start_rot_s, start_sl_s, cmd_r_rot_s, cmd_l_rot_s, cmd_r_sl_s, cmd_l_sl_s)
  begin
    if start_rot_s = '1' then
      cmd_r_mux_s <= cmd_r_rot_s;
      cmd_l_mux_s <= cmd_l_rot_s;
    elsif start_sl_s = '1' then
      cmd_r_mux_s <= cmd_r_sl_s;
      cmd_l_mux_s <= cmd_l_sl_s;
    else
      cmd_r_mux_s <= (others => '0');
      cmd_l_mux_s <= (others => '0');
    end if;
  end process;

  u_pwm : PWM_generation
    port map (
      clk          => CLOCK_50,
      reset_n      => rst_n,
      s_writedataR => cmd_r_mux_s,
      s_writedataL => cmd_l_mux_s,
      dc_motor_p_R => MTRR_P,
      dc_motor_n_R => MTRR_N,
      dc_motor_p_L => MTRL_P,
      dc_motor_n_L => MTRL_N
    );

  u0 : system
    port map (
      leds_export        => led_nios,
      switches_export    => sw_ext,
      clk_clk            => CLOCK_50,
      reset_reset_n      => rst_n,
      sdram_wire_addr    => DRAM_ADDR,
      sdram_wire_ba      => DRAM_BA,
      sdram_wire_cas_n   => DRAM_CAS_N,
      sdram_wire_cke     => DRAM_CKE,
      sdram_wire_cs_n    => DRAM_CS_N,
      sdram_wire_dq      => DRAM_DQ,
      sdram_wire_dqm     => DRAM_DQM,
      sdram_wire_ras_n   => DRAM_RAS_N,
      sdram_wire_we_n    => DRAM_WE_N,
      sdram_clk_clk      => DRAM_CLK,
      motor_right_export => motor_right_dummy,
      motor_left_export  => motor_left_dummy,
      pos_export         => pos_to_nios_s,
      data0r_pio_export  => data0r_s,
      data1r_pio_export  => data1r_s,
      data2r_pio_export  => data2r_s,
      data3r_pio_export  => data3r_s,
      data4r_pio_export  => data4r_s,
      data5r_pio_export  => data5r_s,
      data6r_pio_export  => data6r_s,
      port_s_export      => port_s_s,
      port_e_export      => port_e_s
    );

end architecture;