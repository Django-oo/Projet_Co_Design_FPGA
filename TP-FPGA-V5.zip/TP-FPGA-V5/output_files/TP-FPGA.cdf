/* Quartus II 32-bit Version 13.0.1 Build 232 06/12/2013 Service Pack 1 SJ Full Version */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EP4CE22F17) Path("C:/Users/mfacchi/FPGA/OneDrive_1_09-02-2026-TP3bis/OneDrive_1_09-02-2026/TP-FPGA/output_files/") File("TP-FPGA.sof") MfrSpec(OpMask(1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
