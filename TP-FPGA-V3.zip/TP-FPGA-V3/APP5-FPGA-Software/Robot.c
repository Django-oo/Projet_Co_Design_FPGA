#include <stdint.h>
#include <stdbool.h>

#define WRITEDATA_L  ((volatile uint32_t *)0x00000000u)
#define WRITEDATA_R  ((volatile uint32_t *)0x00000010u)

bool go_r = true,  dir_r = true;
uint16_t duty_cycle_r = 1938;

bool go_l = true,  dir_l = true;
uint16_t duty_cycle_l = 1938;

int main(void)
{
    while (1)
    {
        uint32_t cmd;

        cmd  = ((uint32_t)(go_l ? 1u : 0u) << 13);
        cmd |= ((uint32_t)(dir_l ? 1u : 0u) << 12);
        cmd |= ((uint32_t)(duty_cycle_l & 0x0FFFu));
        *WRITEDATA_L = cmd;

        cmd  = ((uint32_t)(go_r ? 1u : 0u) << 13);
        cmd |= ((uint32_t)(dir_r ? 1u : 0u) << 12);
        cmd |= ((uint32_t)(duty_cycle_r & 0x0FFFu));
        *WRITEDATA_R = cmd;
    }
}
