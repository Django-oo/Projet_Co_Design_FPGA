library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity CTL_SL is
  generic (
    PWM_MAX    : integer := 3125;
    BASE_SPEED : integer := 1500;
    MIN_SPEED  : integer := 900;
    TRIM_R     : integer := 0;
    TRIM_L     : integer := 0
  );
  port (
    clk          : in  std_logic;
    reset_n      : in  std_logic;
    start_sl     : in  std_logic;
    ligne_pres   : in  std_logic;
    pos_ligne    : in  signed(3 downto 0);
    fin_sl       : out std_logic;
    moteur_r_cmd : out std_logic_vector(13 downto 0);
    moteur_l_cmd : out std_logic_vector(13 downto 0)
  );
end entity;

architecture rtl of CTL_SL is

  constant K_POS : integer := 120;

  function clamp(v : integer) return integer is
  begin
    if v < MIN_SPEED then
      return MIN_SPEED;
    elsif v > PWM_MAX then
      return PWM_MAX;
    else
      return v;
    end if;
  end function;

  function make_cmd(go_b : std_logic; dir_b : std_logic; speed_i : integer)
    return std_logic_vector is
    variable tmp : std_logic_vector(13 downto 0);
  begin
    tmp(13) := go_b;
    tmp(12) := dir_b;
    tmp(11 downto 0) := std_logic_vector(to_unsigned(speed_i, 12));
    return tmp;
  end function;

begin

  process(clk, reset_n)
    variable pos_i : integer;
    variable vr    : integer;
    variable vl    : integer;
  begin
    if reset_n = '0' then
      moteur_r_cmd <= (others => '0');
      moteur_l_cmd <= (others => '0');
      fin_sl <= '0';

    elsif rising_edge(clk) then
      if start_sl = '1' then
        if ligne_pres = '0' then
          fin_sl <= '1';
          moteur_r_cmd <= (others => '0');
          moteur_l_cmd <= (others => '0');
        else
          pos_i := to_integer(pos_ligne);

          vr := BASE_SPEED + pos_i * K_POS + TRIM_R;
          vl := BASE_SPEED - pos_i * K_POS + TRIM_L;

          vr := clamp(vr);
          vl := clamp(vl);

          moteur_r_cmd <= make_cmd('1', '0', vr);
          moteur_l_cmd <= make_cmd('1', '0', vl);
          fin_sl <= '0';
        end if;
      else
        moteur_r_cmd <= (others => '0');
        moteur_l_cmd <= (others => '0');
        fin_sl <= '0';
      end if;
    end if;
  end process;

end architecture;